// See LICENSE for license details.

//**************************************************************************
// Software multiply function
//--------------------------------------------------------------------------

// Simple C version
int multiply(int x, int y);

// Simple assembly version
int multiply_asm(int x, int y);
